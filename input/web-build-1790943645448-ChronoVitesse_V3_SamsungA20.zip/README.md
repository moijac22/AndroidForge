# ChronoVitesse V3

Version 3 de l'application pour Samsung A20.

Fonctions :
- GPS automatique ;
- distance totale en km ;
- chronomètre ;
- vitesse moyenne ;
- vitesse instantanée ;
- allure moyenne ;
- allure du dernier kilomètre terminé ;
- état et précision approximative du GPS ;
- bouton DÉMARRER / ARRÊTER ;
- remise à zéro ;
- écran maintenu allumé pendant la séance ;
- une seule page.

## Installation

1. Installer Android Studio sur l'ordinateur.
2. Décompresser ce projet.
3. Dans Android Studio : File > Open puis sélectionner le dossier `ChronoVitesse_V3`.
4. Laisser Gradle synchroniser.
5. Activer le débogage USB sur le Samsung A20.
6. Brancher le téléphone.
7. Accepter l'autorisation de débogage USB sur le téléphone.
8. Sélectionner le Samsung A20 dans Android Studio.
9. Cliquer sur Run (▶).

Au premier lancement, autoriser la localisation.

## Fonctionnement

La distance est calculée en additionnant les segments entre les positions GPS.
La vitesse instantanée utilise la vitesse GPS du téléphone lorsqu'elle est disponible,
avec un calcul de secours à partir du déplacement entre deux positions.

Les sauts de position supérieurs à 100 mètres entre deux mesures sont ignorés
pour limiter les erreurs GPS grossières.

L'allure du dernier kilomètre est mise à jour à chaque kilomètre terminé.
