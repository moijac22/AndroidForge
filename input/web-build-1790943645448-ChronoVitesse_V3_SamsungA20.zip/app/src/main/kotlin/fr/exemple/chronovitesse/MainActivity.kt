package fr.exemple.chronovitesse

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.round

class MainActivity : Activity(), LocationListener {

    private lateinit var chrono: TextView
    private lateinit var distance: TextView
    private lateinit var avgSpeed: TextView
    private lateinit var instantSpeed: TextView
    private lateinit var avgPace: TextView
    private lateinit var kmPace: TextView
    private lateinit var gps: TextView
    private lateinit var start: Button

    private lateinit var locationManager: LocationManager
    private val handler = Handler(Looper.getMainLooper())

    private var running = false
    private var startedAt = 0L
    private var elapsedBefore = 0L

    private var totalMeters = 0.0
    private var lastLocation: Location? = null
    private var lastKmDistance = 0.0
    private var lastKmStartTime = 0L
    private var currentKmPace = "--:-- min/km"

    private val ticker = object : Runnable {
        override fun run() {
            if (running) {
                updateDisplay()
                handler.postDelayed(this, 100)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // L'écran reste allumé pendant une activité.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        buildScreen()
        updateDisplay()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(Color.rgb(245,247,250))
        }

        val title = TextView(this).apply {
            text = "CHRONO GPS"
            textSize = 24f
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(13,71,161))
        }
        root.addView(title, wrap().apply { bottomMargin=dp(3) })

        gps = TextView(this).apply {
            text = "GPS : en attente"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }
        root.addView(gps, wrap().apply { bottomMargin=dp(6) })

        val a = card("TEMPS", "00:00:00.0"); chrono=a.second
        root.addView(a.first, cardParams())

        val b = card("DISTANCE GPS", "0,00 km"); distance=b.second
        root.addView(b.first, cardParams())

        val c = card("VITESSE MOYENNE", "-- km/h"); avgSpeed=c.second
        root.addView(c.first, cardParams())

        val d = card("VITESSE INSTANTANÉE", "-- km/h"); instantSpeed=d.second
        root.addView(d.first, cardParams())

        val e = card("ALLURE MOYENNE", "--:-- min/km"); avgPace=e.second
        root.addView(e.first, cardParams())

        val f = card("ALLURE DERNIER KM", "--:-- min/km"); kmPace=f.second
        root.addView(f.first, cardParams())

        start=Button(this).apply {
            text="DÉMARRER"
            textSize=18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(21,101,192))
            setOnClickListener { toggle() }
        }
        root.addView(start, LinearLayout.LayoutParams(-1,dp(55)).apply {
            topMargin=dp(5); bottomMargin=dp(5)
        })

        val reset=Button(this).apply {
            text="REMISE À ZÉRO"
            textSize=15f
            setOnClickListener { resetAll() }
        }
        root.addView(reset, LinearLayout.LayoutParams(-1,dp(48)))

        setContentView(root)
    }

    private fun toggle() {
        if (!hasPermission()) {
            requestPermissions(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ), 100)
            return
        }
        if (running) stopTracking() else startTracking()
    }

    private fun startTracking() {
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            gps.text="GPS : activez la localisation du téléphone"
            return
        }

        running=true
        startedAt=System.currentTimeMillis()
        elapsedBefore=0L
        totalMeters=0.0
        lastLocation=null
        lastKmDistance=0.0
        lastKmStartTime=startedAt
        currentKmPace="--:-- min/km"

        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 1000L, 1f, this, Looper.getMainLooper()
            )
        } catch (_: SecurityException) {
            running=false
            gps.text="GPS : autorisation refusée"
            return
        }

        gps.text="GPS : recherche de position..."
        start.text="ARRÊTER"
        start.setBackgroundColor(Color.rgb(198,40,40))
        handler.post(ticker)
    }

    private fun stopTracking() {
        elapsedBefore += System.currentTimeMillis()-startedAt
        running=false
        try { locationManager.removeUpdates(this) } catch (_: SecurityException) {}
        handler.removeCallbacks(ticker)
        start.text="DÉMARRER"
        start.setBackgroundColor(Color.rgb(21,101,192))
        gps.text="GPS : arrêté"
        updateDisplay()
    }

    private fun resetAll() {
        running=false
        elapsedBefore=0L
        startedAt=0L
        totalMeters=0.0
        lastLocation=null
        lastKmDistance=0.0
        currentKmPace="--:-- min/km"
        try { locationManager.removeUpdates(this) } catch (_: SecurityException) {}
        handler.removeCallbacks(ticker)
        start.text="DÉMARRER"
        start.setBackgroundColor(Color.rgb(21,101,192))
        gps.text="GPS : en attente"
        updateDisplay()
    }

    override fun onLocationChanged(location: Location) {
        if (!running) return

        val previous=lastLocation
        if (previous != null) {
            val segment=previous.distanceTo(location).toDouble()
            // Filtre simple contre les sauts GPS aberrants.
            if (segment <= 100.0) {
                totalMeters += segment

                // Vitesse instantanée calculée sur le déplacement depuis la
                // dernière position, en utilisant la vitesse GPS si disponible.
                val gpsSpeed=if (location.hasSpeed()) location.speed.toDouble() else -1.0
                val deltaTime=(location.time-previous.time)/1000.0
                val calculated=if (deltaTime > 0.0) segment/deltaTime else -1.0
                val mps=if (gpsSpeed >= 0.0) gpsSpeed else calculated

                if (mps >= 0.0 && mps < 100.0) {
                    instantSpeed.text=String.format(Locale.FRANCE,"%.1f km/h",mps*3.6)
                }

                // Dès qu'un kilomètre supplémentaire est parcouru, on mesure
                // le temps de ce kilomètre et on repart pour le suivant.
                val newKmIndex=(totalMeters/1000.0).toInt()
                val oldKmIndex=((lastKmDistance)/1000.0).toInt()
                if (newKmIndex > oldKmIndex) {
                    val now=System.currentTimeMillis()
                    val kmElapsed=now-lastKmStartTime
                    if (kmElapsed > 0) {
                        currentKmPace=formatPace(kmElapsed/60000.0)
                    }
                    lastKmStartTime=now
                    lastKmDistance=totalMeters
                }
            }
        }

        lastLocation=Location(location)
        gps.text=if (location.accuracy > 0)
            String.format(Locale.FRANCE,"GPS : actif (~ %.0f m)",location.accuracy)
        else "GPS : actif"

        updateDisplay()
    }

    override fun onProviderEnabled(provider:String) {
        if (provider==LocationManager.GPS_PROVIDER && running) gps.text="GPS : actif"
    }

    override fun onProviderDisabled(provider:String) {
        if (provider==LocationManager.GPS_PROVIDER) gps.text="GPS : désactivé"
    }

    override fun onStatusChanged(provider:String?, status:Int, extras:Bundle?) {}

    private fun updateDisplay() {
        val ms=currentElapsed()
        chrono.text=formatChrono(ms)

        val km=totalMeters/1000.0
        distance.text=String.format(Locale.FRANCE,"%.2f km",km)

        if (km >= 0.01 && ms > 0) {
            val hours=ms/3600000.0
            val speed=km/hours
            avgSpeed.text=String.format(Locale.FRANCE,"%.2f km/h",speed)
            avgPace.text=formatPace(60.0/speed)
        } else {
            avgSpeed.text="-- km/h"
            avgPace.text="--:-- min/km"
        }

        kmPace.text=currentKmPace
    }

    private fun currentElapsed():Long =
        elapsedBefore + if (running) System.currentTimeMillis()-startedAt else 0L

    private fun formatChrono(ms:Long):String {
        val tenth=(ms%1000)/100
        val s=ms/1000
        return String.format(Locale.US,"%02d:%02d:%02d.%d",
            s/3600,(s/60)%60,s%60,tenth)
    }

    private fun formatPace(minutes:Double):String {
        val m=minutes.toInt()
        val sec=round((minutes-m)*60).toInt()
        return if (sec>=60)
            String.format(Locale.US,"%02d:00 min/km",m+1)
        else
            String.format(Locale.US,"%02d:%02d min/km",m,sec)
    }

    private fun hasPermission():Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, results:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,results)
        if (requestCode==100 && hasPermission()) startTracking()
        else if (requestCode==100) gps.text="GPS : autorisation nécessaire"
    }

    private fun card(title:String,value:String):Pair<LinearLayout,TextView> {
        val box=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            gravity=Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            elevation=dp(1).toFloat()
        }
        val t=TextView(this).apply {
            text=title; textSize=11f; gravity=Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }
        val v=TextView(this).apply {
            text=value; textSize=25f; gravity=Gravity.CENTER
            setTextColor(Color.rgb(20,20,20))
            setTypeface(null,android.graphics.Typeface.BOLD)
        }
        box.addView(t,wrap()); box.addView(v,wrap())
        return Pair(box,v)
    }

    private fun wrap()=LinearLayout.LayoutParams(-1,-2)
    private fun cardParams()=LinearLayout.LayoutParams(-1,dp(69)).apply { bottomMargin=dp(5) }
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { locationManager.removeUpdates(this) } catch (_:SecurityException) {}
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }
}
