plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="fr.exemple.chronovitesse"
    compileSdk=35
    defaultConfig {
        applicationId="fr.exemple.chronovitesse"
        minSdk=23
        targetSdk=35
        versionCode=3
        versionName="3.0"
    }
}
kotlin { jvmToolchain(17) }
